CREATE TABLE market_data (
instrument_id TEXT,
price FLOAT,
volume FLOAT,
timestamp TIMESTAMP,
PRIMARY KEY (instrument_id, timestamp)
);